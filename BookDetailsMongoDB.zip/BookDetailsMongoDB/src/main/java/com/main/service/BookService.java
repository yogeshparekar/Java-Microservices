package com.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.model.Book;
import com.main.repository.BookRepository;

@Service("bookService")
@Scope("singleton")
@Transactional
public class BookService implements IBookService{

	@Autowired
	@Qualifier("bookRepository")
	private BookRepository bookRepository;
	
	@Override
	public Book saveBook(Book book) {
		return bookRepository.save(book);
	}

	@Override
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	@Override
	public List<Book> saveBooks(List<Book> books) {
		return bookRepository.saveAll(books);
	}

	@Override
	public Book getBookById(String id) {
		return bookRepository.findById(id).orElse(null);
	}

	@Override
	public List<Book> getAllBooksByTitle(String title) {
		return bookRepository.findByTitleLike(title);
	}

	@Override
	public Book update(Book book) {
		return bookRepository.save(book);
	}

	@Override
	public void delete(String id) {
		 bookRepository.deleteById(id);
	}

	@Override
	public List<Book> getAllBooksByPublisher(String publisher) {
		return bookRepository.findByPublisherLike(publisher);
	}

	@Override
	public List<Book> getAllBooksByYear(String year) {
		return bookRepository.findByYearLike(year);
	}

}
