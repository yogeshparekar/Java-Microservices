package com.main.repository;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.main.model.Book;

@Repository("bookRepository")
@Scope("singleton")
public interface BookRepository extends MongoRepository<Book, String> {

	List<Book> findByTitleLike(String title);

	List<Book> findByPublisherLike(String publisher);

	List<Book> findByYearLike(String year);

}
