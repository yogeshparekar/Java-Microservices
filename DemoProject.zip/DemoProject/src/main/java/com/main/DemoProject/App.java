package com.main.DemoProject;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//    	Customer XML Configuration
        System.out.println( "Hello World!" );
        ApplicationContext context = new ClassPathXmlApplicationContext("Bean.xml");
        Customer custObj = (Customer)context.getBean("customer");
        System.out.println(custObj);
        custObj.CustomerMessage();
       
    
        
//    	Product XML Configuration
        Product productObj = (Product)context.getBean("product");
        System.out.println(productObj);
    }
}
