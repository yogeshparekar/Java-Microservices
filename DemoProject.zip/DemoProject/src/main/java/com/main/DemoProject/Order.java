package com.main.DemoProject;

public class Order {
	private int oId;
	private String oName;
	public int getoId() {
		return oId;
	}
	public void setoId(int oId) {
		this.oId = oId;
	}
	public String getoName() {
		return oName;
	}
	public void setoName(String oName) {
		this.oName = oName;
	}
	
	public void placeOrder() {
		System.out.println("Your Order is Placed....");
	}
}
