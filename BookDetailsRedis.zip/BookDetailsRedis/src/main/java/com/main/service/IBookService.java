package com.main.service;

import java.util.List;

import com.main.model.Book;

public interface IBookService {
	
	Book saveBook(Book book);
//	List<Book> saveBooks(List<Book> books);
	Iterable<Book> getAllBooks();
	Book getBookById(String id);
	List<Book> getAllBooksByTitle(String name);
	List<Book> getAllBooksByPublisher(String publisher);
	List<Book> getAllBooksByYear(String year);
	Book update(Book book);
	void delete(String id);
	Iterable<Book> saveBooks(Iterable<Book> books);
}
