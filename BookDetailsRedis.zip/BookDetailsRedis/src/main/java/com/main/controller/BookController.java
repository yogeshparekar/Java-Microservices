package com.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.main.model.Book;
import com.main.service.IBookService;

@RestController
@Scope("request")
public class BookController {

	@Autowired
	@Qualifier("bookService")
	private IBookService bookService;
	
	@PostMapping("/saveBook")
	public Book saveBook(@RequestBody Book book) {
		return bookService.saveBook(book);
	}
	
	@PostMapping("/saveBooks")
	public Iterable<Book> saveBooks(@RequestBody Iterable<Book> books) {
		return bookService.saveBooks(books);
	}
	
	@GetMapping("/getAllBooks")
	public Iterable<Book> getAllBooks() {
		return bookService.getAllBooks();
	}
	
	@GetMapping("/getBookById/{id}")
	public Book getBookById(@PathVariable String id) {
		return bookService.getBookById(id);
	}
	
	@GetMapping("/getBookByTitle/{title}")
	public List<Book> getBookByTitle(@PathVariable String title) {
		return bookService.getAllBooksByTitle(title);
	}
	
	@PutMapping("/updateBook")
	public Book updateBook(@RequestBody Book book) {
		return bookService.update(book);
	}
	
	
	@DeleteMapping("/deleteById/{id}")
	public void deleteBook(@PathVariable String id) {
		 bookService.delete(id);
	}
	
	@GetMapping("/getBooksByPublisher/{publisher}")
	public List<Book> getBooksByPublisher(@PathVariable String publisher){
		return bookService.getAllBooksByPublisher(publisher);
	}
	@GetMapping("/getBooksByYear/{year}")
	public List<Book> getBooksByYear(@PathVariable String year){
		return bookService.getAllBooksByYear(year);
	}
	
}
