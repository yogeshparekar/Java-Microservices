package com.main;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootActuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
