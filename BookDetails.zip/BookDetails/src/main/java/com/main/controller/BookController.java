package com.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.main.model.Book;
import com.main.service.BookService;

import java.util.List;

@RestController
public class BookController {

	@Autowired
	private BookService bookService;
	
	@PostMapping("/saveBook")
	public Book saveBook(@RequestBody Book book) {
		return bookService.saveBook(book);
	}
	
	@PostMapping("/saveBooks")
	public List<Book> saveBooks(@RequestBody List<Book> books) {
		return bookService.saveBooks(books);
	}
	
	@GetMapping("/getAllBooks")
	public List<Book> getAllBooks(){
		return bookService.getBooks();
	}
	
	@GetMapping("/getBookById/{id}")
	public Book getBookById(@PathVariable int id){
		return bookService.findById(id);
	}
	
	@GetMapping("/getBookByTitle/{title}")
	public Book getBookByTitle(@PathVariable String title){
		return bookService.findByTitle(title);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteById(@PathVariable int id) {
		return bookService.deleteById(id);
	}
	
	@PutMapping("updateBook")
	public Book updateBook(@RequestBody Book book) {
		return bookService.updateBook(book);
	}
	
}
