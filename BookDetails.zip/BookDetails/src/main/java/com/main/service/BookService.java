package com.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.model.Book;
import com.main.repository.BookRepository;

import java.util.List;


@Service
public class BookService {
	
	@Autowired
	private BookRepository bookRepository;
	
	public Book saveBook(Book book) {
		return bookRepository.save(book);
	}
	
	public List<Book> saveBooks(List<Book> books){
		return bookRepository.saveAll(books);
	}
	
	public List<Book> getBooks(){
		return bookRepository.findAll();
	}
	
	public Book findById(int id) {
		return bookRepository.findById(id).orElse(null);
	}
	public Book findByTitle(String title) {
		return bookRepository.findByTitle(title);
	}
	
	public String deleteById(int id) {
		 bookRepository.deleteById(id);
		return "Deleted SuccessFully";
	}
	
	public Book updateBook(Book book) {
		return bookRepository.save(book);
	}
	
	
}
